class Drink {
  final String name;
  final String price;
  final String imagePath;

  Drink({
    required this.name,
    required this.price,
    required this.imagePath,
  });
}
